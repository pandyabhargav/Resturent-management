import React from 'react'
import './forgotpass.css'

function Forgotpassform() {
  return (
    <div>Forgotpassform</div>
  )
}

export default Forgotpassform