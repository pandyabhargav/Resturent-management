import React from 'react'
import './forgotpass.css'
function otp() {
  return (
    <div>otp</div>
  )
}

export default otp