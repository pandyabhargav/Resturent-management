import React from 'react'
import './forgotpass.css'
function Resetpass() {
  return (
    <div>Resetpass</div>
  )
}

export default Resetpass